package com.amazonaws.samples;

import java.util.List;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchClientBuilder;
import com.amazonaws.services.cloudwatchevents.AmazonCloudWatchEventsClient;

public class CloudWatch {

//	private AmazonCloudWatchClientBuilder amazonCloudWatchClientBuilder;
//	private AmazonCloudWatchEventsClient amazonCloudWatchEventsClient;
//	
//	public CloudWatch(AWSCredentialsProvider awsCredentials, String region) {
//		 this.amazonCloudWatchClientBuilder = AmazonCloudWatchClientBuilder.standard().withCredentials(awsCredentials);
//		 this.amazonCloudWatchClientBuilder.setRegion(region);
//		 AwsClientBuilder.withCredentials(awsCredentials).build().;
//	}
//	
//	public List<String> getEventLogs(String logGroupName) {
//		
//		
//		return null;
//		
//	}
	
	
	
	
}
